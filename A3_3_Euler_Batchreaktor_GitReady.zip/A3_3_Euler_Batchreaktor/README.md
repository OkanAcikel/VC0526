# A3_3 – Euler-Verfahren für einen Batchreaktor

Dieses Projekt löst die Reaktionskette

```text
A --k1--> B --k2--> C
```

mit dem expliziten und impliziten Euler-Verfahren.

## Gleichungssystem

```text
dcA/dt = -k1*cA
dcB/dt =  k1*cA - k2*cB
dcC/dt =  k2*cB
```

Anfangswert:

```text
cA(0)=1, cB(0)=0, cC(0)=0
```

Standardwerte in `src/main.cpp`:

```text
k1 = 1.0
k2 = 0.5
tStart = 0.0
tEnd = 20.0
h = 0.1
```

## Struktur

```text
include/Backend.h     Vektor-, Matrix- und Gauß-Funktionen
include/Problem.h     Modell, LSM(), RHS() und exakte Lösung
include/Integrator.h  expliziter und impliziter Euler
src/main.cpp          Konfiguration und Programmstart
scripts/plot_results.py optionale Diagramme
```

## Kompilieren mit CMake

```bash
cmake -S . -B build
cmake --build build
```

Linux/macOS:

```bash
./build/A3_3
```

Windows:

```powershell
.\build\Debug\A3_3.exe
```

## Direkt mit g++

```bash
g++ -std=c++17 -Wall -Wextra -Wpedantic -Iinclude src/main.cpp -o A3_3
./A3_3
```

## Ergebnisse

Das Programm schreibt:

```text
results/euler_explicit.csv
results/euler_implicit.csv
```

Die CSV-Dateien enthalten numerische Werte, exakte Werte und relative Fehler.

## Diagramme

Optional:

```bash
python -m pip install pandas matplotlib
python scripts/plot_results.py
```

## Hinweise für den Bericht

- Das explizite Euler-Verfahren ist einfach, reagiert aber empfindlicher auf große Schrittweiten.
- Das implizite Euler-Verfahren benötigt pro Zeitschritt ein Newton-Verfahren.
- Kleinere Schrittweiten verbessern die Genauigkeit.
- Für das geschlossene Reaktionssystem gilt theoretisch `cA + cB + cC = 1`.
