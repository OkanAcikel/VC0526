from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd


def plot_file(csv_file: Path, title: str, output_file: Path) -> None:
    data = pd.read_csv(csv_file)
    plt.figure(figsize=(10, 6))
    plt.plot(data["t"], data["cA"], label="cA numerisch")
    plt.plot(data["t"], data["cB"], label="cB numerisch")
    plt.plot(data["t"], data["cC"], label="cC numerisch")
    plt.plot(data["t"], data["cA_exact"], "--", label="cA exakt")
    plt.plot(data["t"], data["cB_exact"], "--", label="cB exakt")
    plt.plot(data["t"], data["cC_exact"], "--", label="cC exakt")
    plt.xlabel("Zeit t")
    plt.ylabel("Konzentration")
    plt.title(title)
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_file, dpi=200)
    plt.close()


def main() -> None:
    root = Path(__file__).resolve().parent.parent
    results = root / "results"
    plot_file(results / "euler_explicit.csv", "Explizites Euler-Verfahren", results / "euler_explicit.png")
    plot_file(results / "euler_implicit.csv", "Implizites Euler-Verfahren", results / "euler_implicit.png")
    print("Diagramme wurden im Ordner results gespeichert.")


if __name__ == "__main__":
    main()
