#include "Backend.h"
#include "Integrator.h"
#include "Problem.h"

#include <filesystem>
#include <iostream>

int main()
{
    try
    {
        using Backend = StaticBackend<3>;
        using Problem = BatchReactionProblem<Backend>;

        constexpr double k1 = 1.0;
        constexpr double k2 = 0.5;
        constexpr double tStart = 0.0;
        constexpr double tEnd = 20.0;
        constexpr double h = 0.1;

        const Backend::Vector initialValue{1.0, 0.0, 0.0};
        Problem problem(k1, k2);

        std::filesystem::create_directories("results");

        euler_explicit<Problem, Backend> explicitSolver(problem);
        explicitSolver.configure(h, tStart, tEnd);
        explicitSolver.solve(initialValue, "results/euler_explicit.csv");

        euler_implicit<Problem, Backend> implicitSolver(problem);
        implicitSolver.configure(h, tStart, tEnd);
        implicitSolver.configureNewton(1.0e-10, 30);
        implicitSolver.solve(initialValue, "results/euler_implicit.csv");

        std::cout << "Berechnung erfolgreich abgeschlossen.\n"
                  << "Ergebnisse: results/euler_explicit.csv und results/euler_implicit.csv\n";
        return 0;
    }
    catch (const std::exception& exception)
    {
        std::cerr << "Fehler: " << exception.what() << '\n';
        return 1;
    }
}
