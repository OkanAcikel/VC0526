#ifndef BACKEND_H
#define BACKEND_H

#include <array>
#include <cmath>
#include <cstddef>
#include <stdexcept>
#include <utility>

template<std::size_t Dimension>
struct StaticBackend
{
    static constexpr std::size_t dimension = Dimension;
    using Vector = std::array<double, Dimension>;
    using Matrix = std::array<std::array<double, Dimension>, Dimension>;

    static Vector zeroVector()
    {
        Vector result{};
        result.fill(0.0);
        return result;
    }

    static Matrix zeroMatrix()
    {
        Matrix result{};
        for (auto& row : result) row.fill(0.0);
        return result;
    }

    static Matrix identityMatrix()
    {
        Matrix result = zeroMatrix();
        for (std::size_t i = 0; i < Dimension; ++i) result[i][i] = 1.0;
        return result;
    }

    static Vector add(const Vector& a, const Vector& b)
    {
        Vector result{};
        for (std::size_t i = 0; i < Dimension; ++i) result[i] = a[i] + b[i];
        return result;
    }

    static Vector subtract(const Vector& a, const Vector& b)
    {
        Vector result{};
        for (std::size_t i = 0; i < Dimension; ++i) result[i] = a[i] - b[i];
        return result;
    }

    static Vector scale(double factor, const Vector& vector)
    {
        Vector result{};
        for (std::size_t i = 0; i < Dimension; ++i) result[i] = factor * vector[i];
        return result;
    }

    static double norm(const Vector& vector)
    {
        double sum = 0.0;
        for (double value : vector) sum += value * value;
        return std::sqrt(sum);
    }

    static Vector solveLinearSystem(Matrix matrix, Vector rhs)
    {
        constexpr double tolerance = 1.0e-14;

        for (std::size_t column = 0; column < Dimension; ++column)
        {
            std::size_t pivot = column;
            for (std::size_t row = column + 1; row < Dimension; ++row)
            {
                if (std::abs(matrix[row][column]) > std::abs(matrix[pivot][column]))
                    pivot = row;
            }

            if (std::abs(matrix[pivot][column]) < tolerance)
                throw std::runtime_error("Das lineare Gleichungssystem ist singulaer.");

            if (pivot != column)
            {
                std::swap(matrix[pivot], matrix[column]);
                std::swap(rhs[pivot], rhs[column]);
            }

            for (std::size_t row = column + 1; row < Dimension; ++row)
            {
                const double factor = matrix[row][column] / matrix[column][column];
                for (std::size_t j = column; j < Dimension; ++j)
                    matrix[row][j] -= factor * matrix[column][j];
                rhs[row] -= factor * rhs[column];
            }
        }

        Vector solution{};
        for (std::size_t offset = 0; offset < Dimension; ++offset)
        {
            const std::size_t row = Dimension - 1 - offset;
            double sum = rhs[row];
            for (std::size_t column = row + 1; column < Dimension; ++column)
                sum -= matrix[row][column] * solution[column];
            solution[row] = sum / matrix[row][row];
        }
        return solution;
    }
};

#endif
