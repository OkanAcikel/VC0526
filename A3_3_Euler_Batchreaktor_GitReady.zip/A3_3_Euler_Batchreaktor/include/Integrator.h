#ifndef INTEGRATOR_H
#define INTEGRATOR_H

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <fstream>
#include <iomanip>
#include <limits>
#include <stdexcept>
#include <string>

template<typename Problem, typename Backend>
class euler_explicit
{
public:
    using Vector = typename Backend::Vector;

private:
    double h_ = 0.1;
    double tStart_ = 0.0;
    double tEnd_ = 1.0;
    Problem& problem_;

public:
    explicit euler_explicit(Problem& problem) : problem_(problem) {}

    void configure(double h, double tStart, double tEnd)
    {
        if (h <= 0.0) throw std::invalid_argument("h muss positiv sein.");
        if (tEnd <= tStart) throw std::invalid_argument("tEnd muss groesser als tStart sein.");
        h_ = h;
        tStart_ = tStart;
        tEnd_ = tEnd;
    }

    Vector step(double t, const Vector& y) const
    {
        return Backend::add(y, Backend::scale(h_, problem_.RHS(t, y)));
    }

    void solve(const Vector& initialValue, const std::string& fileName) const
    {
        std::ofstream file(fileName);
        if (!file) throw std::runtime_error("Ausgabedatei konnte nicht geoeffnet werden.");

        file << "t,cA,cB,cC,cA_exact,cB_exact,cC_exact,error_cA_percent,error_cB_percent,error_cC_percent\n";
        file << std::setprecision(14);

        double t = tStart_;
        Vector y = initialValue;
        writeLine(file, t, y);

        while (t < tEnd_ - 1.0e-12)
        {
            const double dt = std::min(h_, tEnd_ - t);
            y = Backend::add(y, Backend::scale(dt, problem_.RHS(t, y)));
            t += dt;
            writeLine(file, t, y);
        }
    }

private:
    static double relativeError(double numeric, double exact)
    {
        if (std::abs(exact) < 1.0e-14)
            return std::abs(numeric - exact) < 1.0e-14 ? 0.0 : std::numeric_limits<double>::quiet_NaN();
        return std::abs(numeric - exact) / std::abs(exact) * 100.0;
    }

    void writeLine(std::ofstream& file, double t, const Vector& y) const
    {
        const Vector exact = problem_.exactSolution(t);
        file << t << ',' << y[0] << ',' << y[1] << ',' << y[2] << ','
             << exact[0] << ',' << exact[1] << ',' << exact[2] << ','
             << relativeError(y[0], exact[0]) << ','
             << relativeError(y[1], exact[1]) << ','
             << relativeError(y[2], exact[2]) << '\n';
    }
};

template<typename Problem, typename Backend>
class euler_implicit
{
public:
    using Vector = typename Backend::Vector;
    using Matrix = typename Backend::Matrix;

private:
    double h_ = 0.1;
    double tStart_ = 0.0;
    double tEnd_ = 1.0;
    double tolerance_ = 1.0e-10;
    std::size_t maxIterations_ = 30;
    Problem& problem_;

public:
    explicit euler_implicit(Problem& problem) : problem_(problem) {}

    void configure(double h, double tStart, double tEnd)
    {
        if (h <= 0.0) throw std::invalid_argument("h muss positiv sein.");
        if (tEnd <= tStart) throw std::invalid_argument("tEnd muss groesser als tStart sein.");
        h_ = h;
        tStart_ = tStart;
        tEnd_ = tEnd;
    }

    void configureNewton(double tolerance, std::size_t maxIterations)
    {
        if (tolerance <= 0.0 || maxIterations == 0)
            throw std::invalid_argument("Ungueltige Newton-Konfiguration.");
        tolerance_ = tolerance;
        maxIterations_ = maxIterations;
    }

    Vector step(double t, const Vector& oldY) const
    {
        return stepWithWidth(t, oldY, h_);
    }

    void solve(const Vector& initialValue, const std::string& fileName) const
    {
        std::ofstream file(fileName);
        if (!file) throw std::runtime_error("Ausgabedatei konnte nicht geoeffnet werden.");

        file << "t,cA,cB,cC,cA_exact,cB_exact,cC_exact,error_cA_percent,error_cB_percent,error_cC_percent\n";
        file << std::setprecision(14);

        double t = tStart_;
        Vector y = initialValue;
        writeLine(file, t, y);

        while (t < tEnd_ - 1.0e-12)
        {
            const double dt = std::min(h_, tEnd_ - t);
            y = stepWithWidth(t, y, dt);
            t += dt;
            writeLine(file, t, y);
        }
    }

private:
    Vector stepWithWidth(double t, const Vector& oldY, double dt) const
    {
        const double nextTime = t + dt;
        Vector candidate = Backend::add(oldY, Backend::scale(dt, problem_.RHS(t, oldY)));

        for (std::size_t iteration = 0; iteration < maxIterations_; ++iteration)
        {
            const Vector g = residual(nextTime, oldY, candidate, dt);
            if (Backend::norm(g) < tolerance_) return candidate;

            const Matrix jacobian = numericalJacobian(nextTime, oldY, candidate, dt);
            const Vector correction = Backend::solveLinearSystem(jacobian, Backend::scale(-1.0, g));
            candidate = Backend::add(candidate, correction);

            if (Backend::norm(correction) < tolerance_) return candidate;
        }
        throw std::runtime_error("Newton-Verfahren ist nicht konvergiert.");
    }

    Vector residual(double nextTime, const Vector& oldY, const Vector& candidate, double dt) const
    {
        return Backend::subtract(
            Backend::subtract(candidate, oldY),
            Backend::scale(dt, problem_.RHS(nextTime, candidate))
        );
    }

    Matrix numericalJacobian(double nextTime, const Vector& oldY, const Vector& candidate, double dt) const
    {
        constexpr double epsilon = 1.0e-7;
        Matrix jacobian = Backend::zeroMatrix();

        for (std::size_t column = 0; column < Backend::dimension; ++column)
        {
            Vector plus = candidate;
            Vector minus = candidate;
            plus[column] += epsilon;
            minus[column] -= epsilon;

            const Vector gPlus = residual(nextTime, oldY, plus, dt);
            const Vector gMinus = residual(nextTime, oldY, minus, dt);

            for (std::size_t row = 0; row < Backend::dimension; ++row)
                jacobian[row][column] = (gPlus[row] - gMinus[row]) / (2.0 * epsilon);
        }
        return jacobian;
    }

    static double relativeError(double numeric, double exact)
    {
        if (std::abs(exact) < 1.0e-14)
            return std::abs(numeric - exact) < 1.0e-14 ? 0.0 : std::numeric_limits<double>::quiet_NaN();
        return std::abs(numeric - exact) / std::abs(exact) * 100.0;
    }

    void writeLine(std::ofstream& file, double t, const Vector& y) const
    {
        const Vector exact = problem_.exactSolution(t);
        file << t << ',' << y[0] << ',' << y[1] << ',' << y[2] << ','
             << exact[0] << ',' << exact[1] << ',' << exact[2] << ','
             << relativeError(y[0], exact[0]) << ','
             << relativeError(y[1], exact[1]) << ','
             << relativeError(y[2], exact[2]) << '\n';
    }
};

#endif
