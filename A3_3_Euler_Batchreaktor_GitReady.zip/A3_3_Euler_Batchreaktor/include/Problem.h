#ifndef PROBLEM_H
#define PROBLEM_H

#include "Backend.h"
#include <cmath>
#include <stdexcept>

template<typename Backend>
class BatchReactionProblem
{
public:
    using Vector = typename Backend::Vector;
    using Matrix = typename Backend::Matrix;

private:
    double k1_;
    double k2_;

public:
    BatchReactionProblem(double k1, double k2) : k1_(k1), k2_(k2)
    {
        if (k1_ <= 0.0 || k2_ <= 0.0)
            throw std::invalid_argument("k1 und k2 muessen positiv sein.");
    }

    Matrix LSM() const
    {
        return Backend::identityMatrix();
    }

    Vector RHS(double t, const Vector& y) const
    {
        (void)t;
        const double cA = y[0];
        const double cB = y[1];
        return Vector{
            -k1_ * cA,
             k1_ * cA - k2_ * cB,
             k2_ * cB
        };
    }

    Vector exactSolution(double t) const
    {
        const double cA = std::exp(-k1_ * t);
        double cB;
        if (std::abs(k1_ - k2_) > 1.0e-12)
            cB = k1_ / (k2_ - k1_) * (std::exp(-k1_ * t) - std::exp(-k2_ * t));
        else
            cB = k1_ * t * std::exp(-k1_ * t);
        const double cC = 1.0 - cA - cB;
        return Vector{cA, cB, cC};
    }
};

#endif
